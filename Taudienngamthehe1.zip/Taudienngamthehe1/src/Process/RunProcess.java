
package Process;

import GUI.DangNhap_fr;


/**
 *
 * @author dnh_ntn_ndk
 */
public class RunProcess {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new DangNhap_fr();
    }
    
}
