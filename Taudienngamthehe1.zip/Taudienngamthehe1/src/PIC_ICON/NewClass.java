
package PIC_ICON;

/**
 *
 * @author haita
 */
public class NewClass {
    public static void main(String[] args) {
        System.out.println("");
    }
          
}
